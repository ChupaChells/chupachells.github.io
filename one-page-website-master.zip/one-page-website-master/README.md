# one-page-website
One Page Personal Website

<p align="center">
  <img src="https://github.com/ismailtasdelen/one-page-website/blob/master/assets/images/screenshot.PNG" width="850"/>
</p>
